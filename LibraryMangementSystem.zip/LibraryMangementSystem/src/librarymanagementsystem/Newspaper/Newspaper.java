package librarymanagementsystem.Newspaper;

public class Newspaper {

    private String headline;
    private String editor;
    private String publicationDate;
    private String ISSN; // International Standard Serial Number

    public Newspaper(String headline, String editor, String publicationDate, String ISSN) {
        this.headline = headline;
        this.editor = editor;
        this.publicationDate = publicationDate;
        this.ISSN = ISSN;
    }

    public String getHeadline() {
        return headline;
    }

    public String getEditor() {
        return editor;  
    }

    public String getPublicationDate() {
        return publicationDate;
    }

    public String getISSN() {
        return ISSN;
    }

}
