package librarymanagementsystem.Newspaper;

public interface Prototype {
    // Clone method that returns a copy of the object
    Prototype clone();
}
