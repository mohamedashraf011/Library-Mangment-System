package librarymanagementsystem.DatabaseAndLogger;

public enum TransactionType {
    BORROW, RETURN
}
