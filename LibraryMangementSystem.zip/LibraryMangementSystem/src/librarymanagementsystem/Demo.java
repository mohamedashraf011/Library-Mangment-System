package librarymanagementsystem;

import librarymanagementsystem.DatabaseAndLogger.Database;

import java.sql.Connection;
import javax.swing.JOptionPane;
import librarymanagementsystem.Book.Book;
import librarymanagementsystem.Book.BookBuilder;
import librarymanagementsystem.Book.BookType;
import librarymanagementsystem.Users.User;
import librarymanagementsystem.Users.UserType;

public class Demo {
    public static void main(String[] args) {
        
        Database db = Database.getInstance();
        Connection connection = db.getConnection();
        

        
        Login LoginFrame = new Login();
        LoginFrame.setVisible(true);
        LoginFrame.pack();
        LoginFrame.setLocationRelativeTo(null);

//        
//        Database db1 = Database.getInstance();
//        Database db2 = Database.getInstance();
//        Database db3 = Database.getInstance();
//
//        System.out.println(Database.counter);


//        Book technology = BookFactory.createBook(BookType.SOFTWARE_ENGINEERING);
//        Book software = new SoftwareEngineeringBook("Technology","someone",2014,"123456");
//        // Perform database operations
//        if (connection != null) {
////            db.addBook(new ArtificialIntelligenceBook("Technology","someone",2014,"123456"));
////            db.updateBook(software);
//            db.listBooks();
//        } else {
//            System.out.println("Failed to establish a database connection!");
//        }
    }
}
