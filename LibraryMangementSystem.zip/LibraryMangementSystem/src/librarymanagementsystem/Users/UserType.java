package librarymanagementsystem.Users;

public enum UserType {
    ADMIN,
    REGULAR_USER
}
